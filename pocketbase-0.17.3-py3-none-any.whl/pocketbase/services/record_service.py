from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Generic, TypeVar
from urllib.parse import quote

from pocketbase.models.record import Record
from pocketbase.services.crud_service import CrudService
from pocketbase.services.realtime_service import Callable, MessageData
from pocketbase.utils import camel_to_snake, validate_token

if TYPE_CHECKING:
    from pocketbase.client import Client

T = TypeVar("T", bound=Record)


class RecordAuthResponse(Generic[T]):
    def __init__(
        self,
        token: str,
        record: T,
        meta: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        self.token = token
        self.record = record
        self.meta = meta
        for key, value in kwargs.items():
            setattr(self, key, value)

    @property
    def is_valid(self) -> bool:
        return validate_token(self.token)


@dataclass
class AuthProviderInfo:
    name: str
    display_name: str
    state: str
    auth_url: str
    code_verifier: str
    code_challenge: str
    code_challenge_method: str


@dataclass
class AuthMethodsList:
    @dataclass
    class Password:
        enabled: bool
        identity_fields: list[str]

    @dataclass
    class OAuth2:
        enabled: bool
        providers: list[AuthProviderInfo]

    @dataclass
    class MFA:
        enabled: bool
        duration: int

    @dataclass
    class OTP:
        enabled: bool
        duration: int

    password: Password
    oauth2: OAuth2
    mfa: MFA
    otp: OTP
    # TODO: remove fields below after v0.23 deprecation period
    auth_providers: list[AuthProviderInfo]
    username_password: bool
    email_password: bool
    only_verified: bool = False


class RecordService(CrudService[Record]):
    collection_id_or_name: str

    def __init__(self, client: Client, collection_id_or_name: str) -> None:
        super().__init__(client)
        self.collection_id_or_name = collection_id_or_name

    def decode(self, data: dict[str, Any]) -> Record:
        return Record(data, auto_snake_case=self.client.auto_snake_case)

    def base_crud_path(self) -> str:
        return self.base_collection_path() + "/records"

    def update(
        self,
        id: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> Record:
        """
        If the current `client.auth_store.model` matches with the updated id, then
        on success the `client.auth_store.model` will be updated with the result.
        """
        item = super().update(
            id, body_params=body_params, query_params=query_params
        )
        model = self.client.auth_store.model
        if not isinstance(model, Record):
            return item
        if model.id == item.id and (
            model.collection_id == self.collection_id_or_name
            or model.collection_name == self.collection_id_or_name
        ):
            self.client.auth_store.save(self.client.auth_store.token, item)
        return item

    def delete(
        self, id: str, query_params: dict[str, Any] | None = None
    ) -> bool:
        """
        If the current `client.auth_store.model` matches with the deleted id,
        then on success the `client.auth_store` will be cleared.
        """
        success = super().delete(id, query_params)
        model = self.client.auth_store.model
        if not isinstance(model, Record):
            return success
        if (
            success
            and model.id == id
            and (
                model.collection_id == self.collection_id_or_name
                or model.collection_name == self.collection_id_or_name
            )
        ):
            self.client.auth_store.clear()
        return success

    def base_collection_path(self) -> str:
        """Returns the current collection service base path."""
        return "/api/collections/" + quote(self.collection_id_or_name)

    def subscribe(self, callback: Callable[[MessageData], None]) -> None:
        """Subscribe to realtime changes of any record from the collection."""
        return self.client.realtime.subscribe(
            self.collection_id_or_name, callback
        )

    def subscribe_one(
        self, record_id: str, callback: Callable[[MessageData], None]
    ) -> None:
        """Subscribe to realtime changes of a single record from the collection."""
        return self.client.realtime.subscribe(
            self.collection_id_or_name + "/" + record_id, callback
        )

    def unsubscribe(self, *record_ids: str) -> None:
        """Unsubscribe to the realtime changes of a single record in the collection."""
        if record_ids and len(record_ids) > 0:
            subs: list[str] = []
            for id in record_ids:
                subs.append(self.collection_id_or_name + "/" + id)
            return self.client.realtime.unsubscribe(subs)
        return self.client.realtime.unsubscribe_by_prefix(
            self.collection_id_or_name
        )

    # ------------
    # Auth handers
    # ------------

    def auth_response(
        self, response_data: dict[str, Any]
    ) -> RecordAuthResponse:
        """Prepare successful collection authorization response."""
        record = self.decode(response_data.pop("record", {}))
        token = response_data.pop("token", "")
        if token and record:
            self.client.auth_store.save(token, record)
        return RecordAuthResponse(token=token, record=record, **response_data)  # type: ignore

    def list_auth_methods(
        self, query_params: dict[str, Any] | None = None
    ) -> AuthMethodsList:
        """Returns all available collection auth methods."""
        response_data = self.client.send(
            self.base_collection_path() + "/auth-methods",
            {"method": "GET", "params": query_params},
        )

        def apply_pythonic_keys(ap: dict[str, Any]) -> dict[str, Any]:
            pythonic_keys_ap = {
                camel_to_snake(
                    key, getattr(self.client, "auto_snake_case", True)
                ).replace("@", ""): value
                for key, value in ap.items()
            }
            return pythonic_keys_ap

        password = response_data.get("password", {})
        password_enabled = password.get("enabled", False)
        password_identity_fields = password.get("identityFields", [])
        oauth2 = response_data.get("oauth2", {})
        oauth2_enabled = oauth2.get("enabled", False)
        oauth2_providers_data = oauth2.get("providers", [])
        oauth2_providers: list[AuthProviderInfo] = []
        if oauth2_providers_data:
            oauth2_providers = [
                AuthProviderInfo(**apply_pythonic_keys(provider))
                for provider in oauth2_providers_data
            ]
        mfa = response_data.get("mfa", {})
        mfa_enabled = mfa.get("enabled", False)
        mfa_duration = mfa.get("duration", 0)
        otp = response_data.get("otp", {})
        otp_enabled = otp.get("enabled", False)
        otp_duration = otp.get("duration", 0)

        # TODO: remove deprecated fields below after v0.23 deprecation period
        username_password = response_data.pop("usernamePassword", False)
        email_password = response_data.pop("emailPassword", False)
        auth_providers_data = response_data.get("authProviders", [])
        auth_providers: list[AuthProviderInfo] = []
        if auth_providers_data:
            auth_providers = [
                AuthProviderInfo(**auth_provider)
                for auth_provider in map(
                    apply_pythonic_keys, auth_providers_data
                )
            ]
        return AuthMethodsList(
            password=AuthMethodsList.Password(
                enabled=password_enabled,
                identity_fields=password_identity_fields,
            ),
            oauth2=AuthMethodsList.OAuth2(
                enabled=oauth2_enabled, providers=oauth2_providers
            ),
            mfa=AuthMethodsList.MFA(enabled=mfa_enabled, duration=mfa_duration),
            otp=AuthMethodsList.OTP(enabled=otp_enabled, duration=otp_duration),
            # TODO: remove deprecated fields below after v0.23 deprecation period
            username_password=username_password,
            email_password=email_password,
            auth_providers=auth_providers,
        )

    def auth_with_password(
        self,
        username_or_email: str,
        password: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> RecordAuthResponse:
        """
        Authenticate a single auth collection record via its username/email and password.

        On success, this method also automatically updates
        the client's AuthStore data and returns:
        - the authentication token
        - the authenticated record model
        """
        body_params = body_params or {}
        body_params.update(
            {"identity": username_or_email, "password": password}
        )
        response_data = self.client.send(
            self.base_collection_path() + "/auth-with-password",
            {
                "method": "POST",
                "params": query_params,
                "body": body_params,
                "headers": {"Authorization": ""},
            },
        )
        return self.auth_response(response_data)

    def auth_with_oauth2(
        self,
        provider: str,
        code: str,
        code_verifier: str,
        redirect_url: str,
        create_data: dict[str, Any] | None = None,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> RecordAuthResponse:
        """
        Authenticate a single auth collection record with OAuth2.

        On success, this method also automatically updates
        the client's AuthStore data and returns:
        - the authentication token
        - the authenticated record model
        - the OAuth2 account data (eg. name, email, avatar, etc.)
        """
        body_params = body_params or {}
        body_params.update(
            {
                "provider": provider,
                "code": code,
                "codeVerifier": code_verifier,
                "redirectUrl": redirect_url,
                "createData": create_data,
            }
        )
        response_data = self.client.send(
            self.base_collection_path() + "/auth-with-oauth2",
            {
                "method": "POST",
                "params": query_params,
                "body": body_params,
            },
        )
        return self.auth_response(response_data)

    def auth_refresh(
        self,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> RecordAuthResponse:
        """
        Refreshes the current authenticated record instance and
        returns a new token and record data.

        On success this method also automatically updates the client's AuthStore.
        """
        return self.auth_response(
            self.client.send(
                self.base_collection_path() + "/auth-refresh",
                {"method": "POST", "params": query_params, "body": body_params},
            )
        )

    def request_email_change(
        self,
        newEmail: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> bool:
        """
        Asks to change email of the current authenticated record instance the new address
        receives an email with a confirmation token that needs to be confirmed with confirmEmailChange()
        """
        body_params = body_params or {}
        body_params.update({"newEmail": newEmail})
        self.client.send(
            self.base_collection_path() + "/request-email-change",
            {"method": "POST", "params": query_params, "body": body_params},
        )
        return True

    def confirm_email_change(
        self,
        token: str,
        password: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> bool:
        """
        Confirms Email Change by with the confirmation token and confirm with users password
        """
        body_params = body_params or {}
        body_params.update({"token": token, "password": password})
        self.client.send(
            self.base_collection_path() + "/confirm-email-change",
            {"method": "POST", "params": query_params, "body": body_params},
        )
        return True

    def request_password_reset(
        self,
        email: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> bool:
        """Sends auth record password reset request."""
        body_params = body_params or {}
        body_params.update({"email": email})
        self.client.send(
            self.base_collection_path() + "/request-password-reset",
            {
                "method": "POST",
                "params": query_params,
                "body": body_params,
            },
        )
        return True

    def request_verification(
        self,
        email: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> bool:
        """Sends email verification request."""
        body_params = body_params or {}
        body_params.update({"email": email})
        self.client.send(
            self.base_collection_path() + "/request-verification",
            {
                "method": "POST",
                "params": query_params,
                "body": body_params,
            },
        )
        return True

    def confirm_password_reset(
        self,
        password_reset_token: str,
        password: str,
        password_confirm: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> bool:
        """Confirms auth record password reset request"""
        body_params = body_params or {}
        body_params.update(
            {
                "token": password_reset_token,
                "password": password,
                "passwordConfirm": password_confirm,
            }
        )

        self.client.send(
            self.base_collection_path() + "/confirm-password-reset",
            {
                "method": "POST",
                "params": query_params,
                "body": body_params,
            },
        )
        return True

    def confirm_verification(
        self,
        token: str,
        body_params: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> bool:
        """Confirms email verification request."""
        body_params = body_params or {}
        body_params.update({"token": token})
        self.client.send(
            self.base_collection_path() + "/confirm-verification",
            {
                "method": "POST",
                "params": query_params,
                "body": body_params,
            },
        )
        return True
